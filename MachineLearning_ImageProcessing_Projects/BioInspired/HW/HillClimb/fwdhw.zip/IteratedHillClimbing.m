% Iterated Hill Climbing Algorithm
% Jordan Ringenberg
% Feb. 7, 2012

function [x, initX, step, iter] = IteratedHillClimbing(maxIter, initX, step, iterationRange)
   
    
    best = -1;
    
   	for i = iterationRange
        initX = i;
        [xPrime, ~, ~, iter] = SimpleHillClimbing(maxIter, initX, step);
        
        if fitness(xPrime) > fitness(best)
            best = xPrime;
        end     
    end
    x = best;
end