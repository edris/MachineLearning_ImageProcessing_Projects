% Stochastic Hill Climbing Algorithm
% Jordan Ringenberg
% Feb. 9, 2012

function [x, initX, step, iter] = StochasticHillClimbing(maxIter, initX, step, T)
    
    x = initX;
    iter = 0;
    
    no_improvement = 0;
    
    perturb_denominator = 10;
    while iter < maxIter && no_improvement < 10
            
        p = rand()/perturb_denominator; 
        
        xPrimePlus = x + p;
        xPrimeMinus = x - p;
        
%         if iter < 3
%         rand()
%         prob = 1/(1+exp((fitness(x) - fitness(xPrimeMinus))/T))
%         end
        
        if rand() < 1/(1+exp((fitness(x) - fitness(xPrimePlus))/T)) && xPrimePlus <= 1
            x = xPrimePlus;
            no_improvement = 0;
            perturb_denominator = 10;
        elseif rand() < 1/(1+exp((fitness(x) - fitness(xPrimeMinus))/T)) && xPrimeMinus >= 0
            x = xPrimeMinus;
            no_improvement = 0;
            perturb_denominator = 10;
        else 
          	no_improvement = no_improvement + 1;
        	perturb_denominator = perturb_denominator;
        end
        
        iter = iter + 1;
            
    end
end

