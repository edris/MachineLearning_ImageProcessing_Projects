%Jordan Ringenberg
%Hill Climbing Fitness Function

function fitness = fitness(x)
    fitness = 2^(-2*((x-0.1)/0.9)^2)*(sin(5*pi*x))^6;
end