% Simulated Annealing Algorithm
% Jordan Ringenberg
% Feb. 9, 2012

function [x, initX, step, iter] = SimulatedAnnealing(maxIter, initX, step, T, degradation)

    x = initX;
    iter = 0;
    
    no_improvement = 0;
    
    perturb_denominator = 10;
    while iter < maxIter && no_improvement < 10
            
        p = rand()/perturb_denominator; 
        
        xPrimePlus = x + p;
        xPrimeMinus = x - p;
        
        if rand() < 1/(1+exp((fitness(x) - fitness(xPrimePlus))/T)) && xPrimePlus <= 1
            x = xPrimePlus;
            no_improvement = 0;
            perturb_denominator = 10;
        elseif rand() < 1/(1+exp((fitness(x) - fitness(xPrimeMinus))/T)) && xPrimeMinus >= 0
            x = xPrimeMinus;
            no_improvement = 0;
            perturb_denominator = 10;
        else 
          	no_improvement = no_improvement + 1;
        	perturb_denominator = perturb_denominator;
        end
        
        T = T*degradation;
        iter = iter + 1;
            
    end
end

