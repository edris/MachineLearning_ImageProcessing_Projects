% Simple Hill Climbing Algorithm
% Jordan Ringenberg
% Feb. 9, 2012

function [x, initX, step, iter] = SimpleHillClimbing(maxIter, initX, step)

    x = initX;
    iter = 0;
    
    no_improvement = 0;
    
    perturb_denominator = 10;
    while iter < maxIter && no_improvement < 10
            
        p = rand()/perturb_denominator; 
        
        xPrimePlus = x + p;
        xPrimeMinus = x - p;
        
        if fitness(xPrimePlus) > fitness(x) && xPrimePlus <= 1
            x = xPrimePlus;
            no_improvement = 0;
            perturb_denominator = 10;
        elseif fitness(xPrimeMinus) > fitness(x) && xPrimeMinus >= 0
            x = xPrimeMinus;
            no_improvement = 0;
            perturb_denominator = 10;
        else 
          	no_improvement = no_improvement + 1;
        	perturb_denominator = perturb_denominator * 10;
        end
        
        iter = iter + 1;
            
    end
   
end

