% Jordan Ringenberg
% Feb. 9, 2012

maxIter = 1000;
step = 0.01;
iter = 0;

tic
disp('Simple Hill Climbing');
str = sprintf('Initial X\tIterations\tX Result\tY Result'); %Common Column Headers
disp(str);
for i = 0:0.1:1
    initX = i;
    [x, initX, step, iter] = SimpleHillClimbing(maxIter, initX, step);
    str = sprintf('%f\t%i\t\t%f\t%f\t%f',initX, iter, x, fitness(x));
    disp(str);
end
elapsed = toc

%Two Blank Lines
disp(' ');
disp(' ');

tic
disp('Iterative Hill Climbing');
str = sprintf('Data Range \tStep Size\tX Result\tY Result'); %Common Column Headers
disp(str);
i = 0:0.1:10;
[x, initX, step, iter] = IteratedHillClimbing(maxIter, initX, step, i);
str = sprintf('0.0-1.0\t\t0.1\t\t%f\t%f', x, fitness(x));
disp(str);
elapsed = toc

%Two Blank Lines
disp(' ');
disp(' ');

tic
disp('Stochastic Hill Climbing');
str = sprintf('Initial X\tT\tIterations\tX Result\tY Result'); %Common Column Headers
disp(str);
T = .20;
for i = 0:0.1:1
    initX = i;
    [x, initX, step, iter] = StochasticHillClimbing(maxIter, initX, step, T);
    str = sprintf('%f\t%1.2f\t%i\t\t%f\t%f',initX, T, iter, x, fitness(x));
    disp(str);
end
elapsed = toc

%Two Blank Lines
disp(' ');
disp(' ');

tic
disp('Simluated Annealing');
str = sprintf('Initial X\tT\tD\tIterations\tX Result\tY Result'); %Common Column Headers
disp(str);
T = .20;
D = .5;
for i = 0:0.1:1
    initX = i;
    [x, initX, step, iter] = SimulatedAnnealing(maxIter, initX, step, T, D);
    str = sprintf('%f\t%1.0f\t%1.2f\t%i\t\t%f\t%f',initX, T, D, iter, x, fitness(x));
    disp(str);
end
elapsed = toc

x = 0:0.0001:1;
y = 2.^(-2.*((x-0.1)/0.9).^2).*(sin(5.*pi.*x)).^6;
plot(x,y)
title('Plot of the Fitness Function','FontSize',12)