CSC411
	a few lectures with sample 'm' files

OLDlabs
	labs from neural network course (2009)
	lab1 has overview of (older) Neural Network Toolbox


examples:
	MLPsimulation
	Function approx...
